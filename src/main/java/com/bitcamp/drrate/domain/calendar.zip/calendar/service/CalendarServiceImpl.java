package com.bitcamp.drrate.domain.calendar.service;

import com.bitcamp.drrate.domain.calendar.dto.request.CalendarRequestDTO;
import com.bitcamp.drrate.domain.calendar.dto.response.CalendarResponseDTO;
import com.bitcamp.drrate.domain.calendar.entity.Calendar;
import com.bitcamp.drrate.domain.calendar.repository.CalendarRepository;
import com.bitcamp.drrate.domain.products.repository.InstallMentOptionsRepository;
import com.bitcamp.drrate.domain.products.entity.InstallMentOptions;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CalendarServiceImpl implements CalendarService {

    private final InstallMentOptionsRepository installmentOptionsRepository;
    private final CalendarRepository calendarRepository;

    @Override
    public List<CalendarResponseDTO> getInstallmentProducts() {
        List<InstallMentOptions> options = installmentOptionsRepository.findAll();
        return options.stream()
                .filter(option -> option.getProducts() != null && "적금".equals(option.getProducts().getCtg())) // 적금 필터링
                .map(option -> CalendarResponseDTO.builder()
                        .installmentName(option.getProducts().getPrdName())
                        .bankName(option.getProducts().getBankName())
                        .interestRate(option.getBasicRate() != null ? option.getBasicRate().doubleValue() : 0.0)
                        .build())
                .collect(Collectors.toList());
    }

    @Override
    public void saveCalendarEntry(CalendarRequestDTO request) {
        Calendar calendarEntry = Calendar.builder()
                .calUserId(request.getCalUserId())
                .calInstallmentId(request.getCalInstallmentId())
                .amount(request.getAmount())
                .startDate(request.getStartDate())
                .endDate(request.getEndDate())
                .build();

        calendarRepository.save(calendarEntry);
    }
}
