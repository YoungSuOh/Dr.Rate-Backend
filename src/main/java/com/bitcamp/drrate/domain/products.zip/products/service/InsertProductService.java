package com.bitcamp.drrate.domain.products.service;

public interface InsertProductService {
    public void insertProductData(String d, String depositUrl, boolean b);
}
