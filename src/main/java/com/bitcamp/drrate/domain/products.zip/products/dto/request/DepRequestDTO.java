package com.bitcamp.drrate.domain.products.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

public class DepRequestDTO {

}
