package com.bitcamp.drrate.domain.users.entity;

public enum Role {
    USER,  // 사용자
    ADMIN  // 관리자
}